// Simple test Lambda function
exports.handler = async (event, context) => {
  console.log('Event:', JSON.stringify(event, null, 2));
  
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    'Content-Type': 'application/json'
  };

  function createResponse(statusCode, body) {
    return {
      statusCode: statusCode,
      headers: corsHeaders,
      body: JSON.stringify(body)
    };
  }

  const path = event.path || event.requestContext?.http?.path || '';
  const method = event.httpMethod || event.requestContext?.http?.method;

  console.log(`Method: ${method}, Path: ${path}`);

  try {
    if (path === '/health' && method === 'GET') {
      return createResponse(200, { 
        status: 'healthy', 
        timestamp: new Date().toISOString(),
        message: 'StudySpot API is running (test version)'
      });
    }
    
    if (path === '/api/study-spots' && method === 'GET') {
      return createResponse(200, { 
        study_spots: [
          {
            id: 1,
            name: "University Library",
            location: "Main Campus",
            description: "Quiet study space with WiFi",
            average_rating: 4.5,
            review_count: 23,
            wifi_available: true,
            power_outlets: true,
            noise_level: "Quiet"
          },
          {
            id: 2,
            name: "Student Union",
            location: "Student Center",
            description: "Collaborative study area",
            average_rating: 4.2,
            review_count: 18,
            wifi_available: true,
            power_outlets: true,
            noise_level: "Moderate"
          }
        ]
      });
    }

    return createResponse(404, { error: 'Route not found' });
    
  } catch (error) {
    console.error('Lambda handler error:', error);
    return createResponse(500, { error: 'Internal server error' });
  }
};
